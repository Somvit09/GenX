const express = require('express')

const bodyParser = require('body-parser')

const path = require('path')

const fs = require("fs");

const PUBLISHABLE_KEY = "pk_test_51Iab4zSJV86HjbAqBCo8qN5Pjbk8UMX40rzl41RFDE5Y8nTQnIz4KLWFgl0YC30Atd7TqfOA0RgMu5x54SCvyqxH00i91ssJpH"

const SECRET_KEY = "sk_test_51Iab4zSJV86HjbAqjl0cMkFM810wiyDoZ0SwPOca0572tC8anaY8OWoFeJg5gzjKxtSHqxVzqnU9kBLzYnFxTZby00u3IJUUq8"

const stripe = require('stripe')(SECRET_KEY)

const app = express()

app.use(express.urlencoded({
    extended: false
}))
app.use(express.json())

app.set("view engine", "ejs")

const PORT = process.env.PORT || 3000

app.get('/', (req, res) => {
    res.render('Home', {
        key: PUBLISHABLE_KEY
    })
})

app.post('/payment', (req, res) => {
    stripe.customers.create({
            email: req.body.stripeEmail,
            source: req.body.stripeToken,
            name: 'Lucifer Thomson',
            address: {
                line1: '23 Mountain gali',
                postal_code: '110034',
                city: 'Delhi',
                state: 'New Delhi',
                country: 'India'
            }
        })
        .then((customer) => {
            return stripe.charges.create({
                amount: 7000,
                description: 'Web Develeopment Product',
                currency: 'INR',
                customer: customer.id
            })
        })
        .then((charge) => {
            let output = {
                id: charge.id,
                amount: charge.amount,
                create_time: charge.created,
                status: charge.status,
                payer_id: charge.source.id,
                payer_brand: charge.source.brand,
                payer_country: charge.source.country,
                payer_cvc_check: charge.source.cvc_check,
                payer_card_expiry_month: charge.source.exp_month,
                payer_card_expiry_year: charge.source.exp_year,
                payer_email: charge.source.name,
                amount_refunded: charge.amount_refunded,
                receipt_url: charge.receipt_url,
                intent: charge.payment_intent
            }
            res.send(JSON.stringify(output));
            //Result is of the transaction is shown in jsonData.json file and that code is below. 
            const jsonData = JSON.stringify(output);
            fs.writeFile('jsonData.json', jsonData, (err)=>{
                console.log("done");
            })
        })
        .catch((err) => {
            res.send(err)
        })
})


app.listen(PORT, () => {
    console.log(`App is listening on ${PORT}`)
})